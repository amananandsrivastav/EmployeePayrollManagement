# Employee-Payroll-Management-RLL-GROUP-3
This is the systematic approach for employee payroll system.
